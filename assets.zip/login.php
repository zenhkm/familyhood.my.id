<?php
// HAPUS INI: session_start(); 
// GANTI JADI:
require_once 'init_session.php';

require_once 'config_google.php';

// --- LOGIKA LOGIN GOOGLE ---

if (isset($_GET['code'])) {
    try {
        // 1. Tukar Code dengan Token
        $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
        
        // Cek jika ada error pada token
        if (isset($token['error'])) {
            throw new Exception("Gagal mendapatkan token: " . $token['error']);
        }
        
        $client->setAccessToken($token);

        // 2. Ambil Data Profil User dari Google
        $google_oauth = new Google_Service_Oauth2($client);
        $google_account_info = $google_oauth->userinfo->get();
        
        $email = $google_account_info->email;
        $name  = $google_account_info->name;

        // 3. KONEKSI DATABASE
        $mysqli = new mysqli('localhost', 'quic1934_zenhkm', '03Maret1990', 'quic1934_familyhood');
        if ($mysqli->connect_error) {
            die("Koneksi Database Gagal: " . $mysqli->connect_error);
        }
        
        // 4. CEK EMAIL DI TABEL 'users' (Bukan allowed_users lagi)
        $stmt = $mysqli->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

       // ... (kode sebelumnya tetap sama)

        if ($user) {
            // --- SKENARIO 1: USER SUDAH TERDAFTAR (LOGIN) ---
            
            // Kita update google_id dan foto terbaru biar sinkron
            $stmt_update = $mysqli->prepare("UPDATE users SET google_id = ?, photo_url = ?, updated_at = NOW() WHERE id = ?");
            // Ambil foto profil google (jika ada)
            $picture = $google_account_info->picture; 
            $stmt_update->bind_param("ssi", $google_account_info->id, $picture, $user['id']);
            $stmt_update->execute();

            // Set Session
            $_SESSION['is_logged_in'] = true;
            $_SESSION['user_id']    = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_name']  = $user['name'];
            $_SESSION['role']       = $user['role'];
            
            header("Location: index.php");
            exit;

        } else {
            // --- SKENARIO 2: USER BARU (AUTO REGISTER) ---
            
            // Kita daftarkan user baru ini
            // Password kita isi string random karena login pakai Google
            // Role default = 'user'
            
            $googleId = $google_account_info->id;
            $picture  = $google_account_info->picture;
            $dummyPass = password_hash("google_" . time(), PASSWORD_DEFAULT); 

            $stmt_insert = $mysqli->prepare("INSERT INTO users (email, name, role, password, google_id, photo_url) VALUES (?, ?, 'user', ?, ?, ?)");
            $stmt_insert->bind_param("sssss", $email, $name, $dummyPass, $googleId, $picture);
            
            if ($stmt_insert->execute()) {
                // Berhasil Daftar -> Langsung Login Otomatis
                $newId = $stmt_insert->insert_id;
                
                $_SESSION['is_logged_in'] = true;
                $_SESSION['user_id']    = $newId;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_name']  = $name;
                $_SESSION['role']       = 'user';
                
                // Beri notifikasi selamat datang di index (opsional)
                // header("Location: index.php?welcome=1"); 
                header("Location: index.php");
                exit;
            } else {
                echo "Gagal mendaftarkan akun: " . $stmt_insert->error;
                exit;
            }
        }
        
        // ... (sisa kode di bawahnya biarkan saja)
    } catch (Exception $e) {
        echo "Terjadi kesalahan: " . $e->getMessage();
        exit;
    }
}

// Jika sudah login, lempar ke index
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Dapatkan URL Login
$login_url = $client->createAuthUrl();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - FamilyHood</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { display: flex; justify-content: center; align-items: center; height: 100vh; background: #f3f4f6; font-family: sans-serif; margin: 0; }
        .login-card { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center; max-width: 400px; width: 100%; }
        .btn-google {
            display: inline-flex; align-items: center; justify-content: center; gap: 10px;
            background: #ffffff; color: #555; border: 1px solid #ddd;
            padding: 12px 24px; text-decoration: none; border-radius: 5px; 
            font-weight: bold; margin-top: 20px; transition: 0.2s;
        }
        .btn-google:hover { background: #f9fafb; border-color: #ccc; }
        h1 { color: #4f46e5; margin-bottom: 10px; }
        p { color: #6b7280; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="login-card">
        <svg width="50" height="50" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-bottom:10px;">
            <rect width="512" height="512" rx="100" fill="#4f46e5"/>
            <path d="M256 150V250" stroke="white" stroke-width="32" stroke-linecap="round"/>
            <path d="M256 250L150 340" stroke="white" stroke-width="32" stroke-linecap="round"/>
            <path d="M256 250L362 340" stroke="white" stroke-width="32" stroke-linecap="round"/>
            <circle cx="256" cy="140" r="60" fill="white"/>
        </svg>
        <h1>FamilyHood</h1>
        <p>Kelola silsilah keluarga Anda dengan mudah, aman, dan rapi.</p>
        
        <a href="<?= $login_url ?>" class="btn-google">
            <img src="https://www.svgrepo.com/show/475656/google-color.svg" width="20" height="20">
            Login dengan Google
        </a>
    </div>
</body>
</html>