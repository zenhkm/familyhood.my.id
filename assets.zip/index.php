<?php
// HAPUS INI: session_start();
// GANTI JADI:
require_once 'init_session.php';

// --- PERBAIKAN: DEFINISIKAN ACTION DI SINI ---
$action = $_GET['action'] ?? 'home';
// --- LOGIKA LOGOUT ---
if ($action === 'logout') {
    $_SESSION = [];         // Kosongkan array session
    session_unset();        // Hapus semua variabel session
    session_destroy();      // Hancurkan session di server
    header("Location: login.php"); // Redirect ke halaman login
    exit;
}
// ---------------------------------------------

// --- CEK LOGIN ---
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// ... (lanjutkan dengan kode di bawahnya seperti biasa)

// Cek Admin
// Pastikan session menyimpan user_id dan role saat login
$myUserId = $_SESSION['user_id'] ?? 0; 
$myRole   = $_SESSION['role'] ?? 'user';
$isAdmin  = ($myRole === 'admin');

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Konfigurasi database
$DB_HOST = 'localhost';
$DB_USER = 'quic1934_zenhkm';
$DB_PASS = '03Maret1990';
$DB_NAME = 'quic1934_familyhood';

// Koneksi
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_errno) die('Gagal konek database: ' . $mysqli->connect_error);
$mysqli->set_charset('utf8mb4');

// --- FUNGSI BANTUAN: KIRIM NOTIFIKASI ---
function fh_send_notification($mysqli, $userId, $title, $message, $type='info') {
    $stmt = $mysqli->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $userId, $title, $message, $type);
    $stmt->execute();
    $stmt->close();
}


// --- AUTOMATIC TRIGGERS (Saat Halaman Dibuka) ---

// 1. Cek Selamat Datang (Jika User Baru belum punya notifikasi sama sekali)
$checkWelcome = $mysqli->query("SELECT id FROM notifications WHERE user_id = $myUserId LIMIT 1");
if ($checkWelcome->num_rows == 0) {
    fh_send_notification($mysqli, $myUserId, "Selamat Datang! 👋", "Selamat datang di FamilyHood! Mulailah dengan menambahkan diri Anda atau orang tua Anda di menu 'Tambah'.", "info");
}

// 2. Cek Ulang Tahun Keluarga (Hari Ini)
// Hanya cek jika user membuka halaman Dashboard/Home
if ($action === 'home') {
    $todayMD = date('m-d');
    $yearNow = date('Y');
    
    // Cari anggota keluarga (milik user ini) yang ulang tahun hari ini
    $sqlBday = "SELECT id, name, date_of_birth FROM persons WHERE user_id = $myUserId AND DATE_FORMAT(date_of_birth, '%m-%d') = '$todayMD'";
    $resBday = $mysqli->query($sqlBday);
    
    while ($p = $resBday->fetch_assoc()) {
        // Cek apakah sudah dikirimi notif tahun ini? (Supaya tidak spam tiap refresh)
        $msgTitle = "Selamat Ulang Tahun, " . $p['name'] . "! 🎂";
        $checkSent = $mysqli->query("SELECT id FROM notifications WHERE user_id = $myUserId AND title = '$msgTitle' AND YEAR(created_at) = '$yearNow'");
        
        if ($checkSent->num_rows == 0) {
            // Hitung Umur
            $dob = new DateTime($p['date_of_birth']);
            $today = new DateTime();
            $age = $today->diff($dob)->y;
            
            fh_send_notification($mysqli, $myUserId, $msgTitle, "Hari ini " . $p['name'] . " berulang tahun yang ke-$age. Jangan lupa ucapkan selamat!", "birthday");
        }
    }
}

// --- LOGIKA "SIAPA MELIHAT SIAPA" ---
// Default: Kita melihat data kita sendiri
$targetUserId = $myUserId; 
$isViewingOthers = false;

// Khusus Admin: Bisa melihat data orang lain jika diizinkan
if ($isAdmin && isset($_GET['view_user_id'])) {
    $requestedId = intval($_GET['view_user_id']);
    if ($requestedId !== $myUserId) {
        // Cek apakah user target mengizinkan admin melihat (allow_admin_view = 1)
        $check = $mysqli->query("SELECT allow_admin_view, name FROM users WHERE id=$requestedId")->fetch_assoc();
        
        // Jika diizinkan ATAU user targetnya admin sendiri (untuk testing)
        if ($check && $check['allow_admin_view'] == 1) {
            $targetUserId = $requestedId;
            $isViewingOthers = true;
            $targetUserName = $check['name'];
        } else {
            die("Akses Ditolak: User ini tidak mengizinkan Admin melihat pohon keluarganya.");
        }
    }
}

// --- HELPER FUNCTIONS ---

function fh_render_single_web_card($p, $currentActiveId) {
    $photoUrl = 'assets/l.png';
    if (($p['gender']??'') === 'P') $photoUrl = 'assets/p.png';
    if (!empty($p['photo']) && file_exists(__DIR__ . '/' . $p['photo'])) {
        $photoUrl = $p['photo'];
    }
    $isHighlight = ($p['id'] == $currentActiveId) ? 'highlight' : '';
    echo '<a href="?action=bio&id='.$p['id'].'&mode=view" class="tree-node-web">';
    echo '  <div class="node-card-content '.$isHighlight.'">';
    echo '      <img src="'.$photoUrl.'" class="web-photo">';
    echo '      <span class="web-name">'.htmlspecialchars($p['name']).'</span>';
    echo '  </div>';
    echo '</a>';
}

function fh_get_all_persons($mysqli, $userId) {
    $rows = [];
    if (!$mysqli) return $rows;
    // Tambahkan WHERE user_id
    $sql = "SELECT id, name, place_of_birth, date_of_birth, gender, is_alive, note, created_at, updated_at, photo 
            FROM persons 
            WHERE user_id = $userId 
            ORDER BY name ASC";
    if ($result = $mysqli->query($sql)) {
        while ($row = $result->fetch_assoc()) { $rows[] = $row; }
        $result->free();
    }
    return $rows;
}

// --- LOGIKA GENERASI ---
function fh_compute_generations($mysqli, $userId) {
    $persons = []; $childParents = []; $parentChildren = []; 
    $spouses = []; $parents = []; $children = [];

    if (!$mysqli) return [[], 0, 0, [], [], [], []];

    // Filter Persons milik User
    $sqlPersons = "SELECT id, name, date_of_birth, gender, photo FROM persons WHERE user_id = $userId ORDER BY id ASC";
    if ($res = $mysqli->query($sqlPersons)) {
        while ($row = $res->fetch_assoc()) {
            $id = (int)$row['id'];
            $persons[$id] = [
                'id' => $id, 'name' => $row['name'], 'dob' => $row['date_of_birth'] ?? null,
                'gender' => $row['gender'], 'photo' => $row['photo'],
            ];
        }
        $res->free();
    }
    if (empty($persons)) return [[], 0, 0, [], [], [], []];

    // Filter Relasi Orang Tua milik User
    $sqlRelParent = "SELECT person_id, related_person_id, relation_type FROM relations WHERE user_id = $userId AND relation_type IN ('ayah','ibu')";
    if ($res = $mysqli->query($sqlRelParent)) {
        while ($row = $res->fetch_assoc()) {
            $child = (int)$row['person_id']; $parent = (int)$row['related_person_id'];
            if (!isset($childParents[$child])) $childParents[$child] = [];
            $childParents[$child][$parent] = true;
            if (!isset($parentChildren[$parent])) $parentChildren[$parent] = [];
            $parentChildren[$parent][$child] = true;
            $parents[$parent] = true; $children[$child] = true;
        }
        $res->free();
    }

    // Filter Relasi Pasangan milik User
    $sqlRelSpouse = "SELECT person_id, related_person_id FROM relations WHERE user_id = $userId AND relation_type = 'pasangan'";
    if ($res = $mysqli->query($sqlRelSpouse)) {
        while ($row = $res->fetch_assoc()) {
            $a = (int)$row['person_id']; $b = (int)$row['related_person_id'];
            if (!isset($spouses[$a])) $spouses[$a] = [];
            if (!isset($spouses[$b])) $spouses[$b] = [];
            $spouses[$a][$b] = true; $spouses[$b][$a] = true;
        }
        $res->free();
    }

    // --- LOGIKA HITUNG GENERASI (Tidak berubah) ---
    // Cari Root
    $rootPersons = [];
    foreach ($persons as $pid => $p) {
        $isParent = !empty($parents[$pid]);
        $isChild  = !empty($children[$pid]);
        if ($isParent && !$isChild) {
            $rootPersons[] = $pid;
        }
    }
    if (empty($rootPersons)) {
        foreach ($persons as $pid => $p) {
            if (empty($childParents[$pid])) $rootPersons[] = $pid;
        }
    }

    $generation = []; $queue = [];
    foreach ($rootPersons as $rid) {
        if (!isset($generation[$rid])) { $generation[$rid] = 1; $queue[] = $rid; }
    }

    for ($i = 0; $i < count($queue); $i++) {
        $person = $queue[$i]; $g = $generation[$person];
        if (!empty($spouses[$person])) {
            foreach ($spouses[$person] as $spouseId => $_) {
                if (!isset($generation[$spouseId])) { $generation[$spouseId] = $g; $queue[] = $spouseId; }
            }
        }
        if (!empty($parentChildren[$person])) {
            foreach ($parentChildren[$person] as $childId => $_) {
                $newGen = $g + 1;
                if (!isset($generation[$childId]) || $generation[$childId] < $newGen) {
                    $generation[$childId] = $newGen; $queue[] = $childId;
                }
            }
        }
    }

    $changed = true;
    while ($changed) {
        $changed = false;
        foreach ($spouses as $a => $list) {
            foreach ($list as $b => $_) {
                if (!isset($generation[$a]) || !isset($generation[$b])) continue;
                $maxG = max($generation[$a], $generation[$b]);
                if ($generation[$a] < $maxG) { $generation[$a] = $maxG; $changed = true; }
                if ($generation[$b] < $maxG) { $generation[$b] = $maxG; $changed = true; }
            }
        }
    }
    foreach ($persons as $pid => $_) { if (!isset($generation[$pid])) $generation[$pid] = 1; }

    $personsByGen = []; $maxGen = 0;
    foreach ($generation as $pid => $g) {
        if ($g < 1) $g = 1;
        if (!isset($personsByGen[$g])) $personsByGen[$g] = [];
        $personsByGen[$g][] = $persons[$pid]['name'];
        if ($g > $maxGen) $maxGen = $g;
    }
    
    return [$personsByGen, $maxGen, 0, $generation, $persons, $parentChildren, $spouses];
}

// --- FUNGSI PENGGABUNG KELUARGA (UNION-FIND) ---
function fh_group_anchors($anchors, $persons, $spouses, $parentChildren) {
    $parent = [];
    foreach (array_keys($persons) as $id) $parent[$id] = $id;
    
    $find = function($i) use (&$parent) {
        $path = [];
        while ($parent[$i] != $i) { $path[] = $i; $i = $parent[$i]; }
        foreach ($path as $node) $parent[$node] = $i;
        return $i;
    };
    $union = function($i, $j) use (&$parent, $find) {
        $root_i = $find($i); $root_j = $find($j);
        if ($root_i != $root_j) $parent[$root_i] = $root_j;
    };
    
    foreach ($spouses as $a => $list) { foreach ($list as $b => $_) $union($a, $b); }
    foreach ($parentChildren as $p => $kids) { foreach ($kids as $k => $_) $union($p, $k); }
    
    $groups = [];
    foreach ($anchors as $a) {
        $root = $find($a);
        if (!isset($groups[$root])) $groups[$root] = [];
        $groups[$root][] = $a;
    }
    return array_values($groups);
}

// --- HITUNG TOTAL ANGGOTA DALAM CLUSTER (Helper Baru) ---
function fh_count_descendants($rootIds, $spouses, $parentChildren, &$visited) {
    $count = 0;
    $queue = $rootIds;
    
    while(!empty($queue)) {
        $currentId = array_shift($queue);
        if (isset($visited[$currentId])) continue;
        $visited[$currentId] = true;
        $count++;

        // Tambahkan Pasangan ke queue
        if (!empty($spouses[$currentId])) {
            foreach ($spouses[$currentId] as $sId => $_) {
                if (!isset($visited[$sId])) $queue[] = $sId;
            }
        }
        // Tambahkan Anak ke queue
        if (!empty($parentChildren[$currentId])) {
            foreach ($parentChildren[$currentId] as $cId => $_) {
                if (!isset($visited[$cId])) $queue[] = $cId;
            }
        }
    }
    return $count;
}

function fh_render_tree_web($personId, $persons, $spouses, $parentChildren, $currentActiveId) {
    if (!isset($persons[$personId])) return;
    $p = $persons[$personId];
    echo '<li>';
    echo '<div style="display:inline-flex; align-items:center;">';
    fh_render_single_web_card($p, $currentActiveId);
    if (!empty($spouses[$personId])) {
        foreach ($spouses[$personId] as $spouseId => $_) {
            if (isset($persons[$spouseId])) {
                echo '<div class="spouse-connector-web"></div>';
                fh_render_single_web_card($persons[$spouseId], $currentActiveId);
            }
        }
    }
    echo '</div>';
    
    $groupIds = [$personId];
    if (!empty($spouses[$personId])) {
        foreach ($spouses[$personId] as $sid => $_) { $groupIds[] = $sid; }
    }
    
    $childIdsMap = [];
    foreach ($groupIds as $pid) {
        if (!empty($parentChildren[$pid])) {
            foreach ($parentChildren[$pid] as $cid => $_) { $childIdsMap[$cid] = true; }
        }
    }
    $childIds = array_keys($childIdsMap);
    
    if (!empty($childIds)) {
        usort($childIds, function($a, $b) use ($persons) {
            $da = $persons[$a]['dob'] ?? null; $db = $persons[$b]['dob'] ?? null;
            $ka = ($da && $da !== '0000-00-00') ? $da : null; $kb = ($db && $db !== '0000-00-00') ? $db : null;
            if ($ka && $kb && $ka !== $kb) return strcmp($ka, $kb); elseif ($ka && !$kb) return -1; elseif (!$ka && $kb) return 1;
            return strnatcasecmp($persons[$a]['name'], $persons[$b]['name']);
        });
        echo '<ul>';
        foreach ($childIds as $childId) {
            fh_render_tree_web($childId, $persons, $spouses, $parentChildren, $currentActiveId);
        }
        echo '</ul>';
    }
    echo '</li>';
}

// --- DATA EXPORT HELPERS (Sama seperti sebelumnya) ---
function fh_get_group_label_for_person($id, $gen, $generation, $persons, $spouses) {
    if (!isset($persons[$id])) return '';
    $mainId = $id; $otherIds = [];
    if (!empty($spouses[$mainId])) {
        foreach ($spouses[$mainId] as $spouseId => $_) { if (isset($persons[$spouseId])) $otherIds[] = $spouseId; }
    }
    usort($otherIds, function($a, $b) use ($persons) {
        $da = $persons[$a]['dob'] ?? null; $db = $persons[$b]['dob'] ?? null;
        $ka = ($da && $da !== '0000-00-00') ? $da : null; $kb = ($db && $db !== '0000-00-00') ? $db : null;
        if ($ka && $kb) { if ($ka !== $kb) return strcmp($ka, $kb); } elseif ($ka && !$kb) return -1; elseif (!$ka && $kb) return 1;
        return strnatcasecmp($persons[$a]['name'], $persons[$b]['name']);
    });
    $groupIds = array_merge([$mainId], $otherIds);
    $names = [];
    foreach ($groupIds as $pid) $names[] = $persons[$pid]['name'];
    return implode(' & ', $names);
}

function fh_get_family_rows_recursive($personId, $currentGen, $persons, $spouses, $parentChildren, $generationData, $childNumber = null) {
    $label = fh_get_group_label_for_person($personId, $currentGen, $generationData, $persons, $spouses);
    if ($currentGen > 1 && $childNumber !== null) $label = $childNumber . '. ' . $label;

    $groupIds = [$personId];
    if (!empty($spouses[$personId])) {
        foreach ($spouses[$personId] as $sid => $_) $groupIds[] = $sid;
    }
    $childIdsMap = [];
    foreach ($groupIds as $pid) {
        if (!empty($parentChildren[$pid])) {
            foreach ($parentChildren[$pid] as $cid => $_) $childIdsMap[$cid] = true;
        }
    }
    $childIds = array_keys($childIdsMap);

    if (empty($childIds)) return [[ $currentGen => $label ]];

    usort($childIds, function($a, $b) use ($persons) {
        $da = $persons[$a]['dob'] ?? null; $db = $persons[$b]['dob'] ?? null;
        $ka = ($da && $da !== '0000-00-00') ? $da : null; $kb = ($db && $db !== '0000-00-00') ? $db : null;
        if ($ka && $kb && $ka !== $kb) return strcmp($ka, $kb); elseif ($ka && !$kb) return -1; elseif (!$ka && $kb) return 1;
        return strnatcasecmp($persons[$a]['name'], $persons[$b]['name']);
    });

    $allDescendantRows = [];
    $childGen = $currentGen + 1;
    foreach ($childIds as $index => $childId) {
        $nextNumber = $index + 1;
        $childRows = fh_get_family_rows_recursive($childId, $childGen, $persons, $spouses, $parentChildren, $generationData, $nextNumber);
        foreach ($childRows as $row) $allDescendantRows[] = $row;
    }
    if (isset($allDescendantRows[0])) $allDescendantRows[0][$currentGen] = $label;
    return $allDescendantRows;
}
// === EXPORT HANDLERS (UPDATED) ===
if (isset($_GET['export'])) {
    global $mysqli;
    
    // 1. Ambil Filter ID jika ada
    $filterRootId = isset($_GET['filter_root']) ? intval($_GET['filter_root']) : 0;

    // 2. Hitung Generasi (Sama seperti View)
    list($personsByGen, $maxGen, $maxHeight, $generation, $persons, $parentChildren, $spouses) = fh_compute_generations($mysqli, $targetUserId);

    // 3. Tentukan Siapa yang akan di-Export (Roots)
    $rootsToExport = [];

    if ($filterRootId > 0) {
        // KASUS 1: Export SATU Keluarga Saja
        // Validasi: pastikan ID ini ada
        if (isset($persons[$filterRootId])) {
            $rootsToExport[] = $filterRootId;
        }
    } else {
        // KASUS 2: Export SEMUA Keluarga (Sama seperti Tampilan Awal)
        // Cari semua Gen 1
        $allRoots = [];
        foreach ($persons as $pid => $info) {
            if (($generation[$pid] ?? 999) == 1) {
                $allRoots[] = $pid;
            }
        }
        // Urutkan Nama
        usort($allRoots, function($a, $b) use ($persons) { 
            return strnatcasecmp($persons[$a]['name'], $persons[$b]['name']); 
        });

        // Deduplikasi Pasangan (Agar suami istri tidak muncul 2x sebagai judul terpisah)
        $processed = [];
        foreach ($allRoots as $rid) {
            if (isset($processed[$rid])) continue;
            
            // Masukkan ke daftar export
            $rootsToExport[] = $rid;
            $processed[$rid] = true;

            // Tandai pasangannya agar tidak masuk lagi
            if (!empty($spouses[$rid])) {
                foreach($spouses[$rid] as $sid => $_) {
                    // Hanya tandai jika pasangan juga Gen 1
                    if (($generation[$sid]??0) == 1) $processed[$sid] = true;
                }
            }
        }
    }

    // --- LOGIC EXCEL & WORD ---
    if ($_GET['export'] === 'excel' || $_GET['export'] === 'word') {
        $finalRows = [];
        $realMaxGen = 0;

        foreach ($rootsToExport as $anchorId) {
            // Ambil data hierarki recursive
            $startGen = $generation[$anchorId] ?? 1;
            // Reset startGen jadi 1 agar di Excel selalu mulai dari kolom A
            // Kecuali kita mau mempertahankan level asli, tapi biasanya export dimulai dari kiri.
            // Kita pakai logic: Gen orang ini dianggap Gen 1 untuk export ini.
            
            $familyRows = fh_get_family_rows_recursive($anchorId, 1, $persons, $spouses, $parentChildren, $generation, null);
            
            foreach ($familyRows as $fRow) {
                $maxKey = max(array_keys($fRow));
                if ($maxKey > $realMaxGen) $realMaxGen = $maxKey;
                $finalRows[] = $fRow;
            }
            $finalRows[] = []; // Jarak antar keluarga
        }

        $filename = "familyhood_export_" . ($filterRootId ? "bani_".$filterRootId : "all") . "_" . date('Ymd_His');

        if ($_GET['export'] === 'excel') {
            header("Content-Type: application/vnd.ms-excel; charset=utf-8");
            header("Content-Disposition: attachment; filename=".$filename.".xls");
            header("Cache-Control: max-age=0");
            echo '<html><head><meta charset="utf-8" /></head><body><table border="1">';
            echo '<thead><tr>';
            for ($g = 1; $g <= $realMaxGen; $g++) echo '<th style="background-color:#eee;">Generasi '.$g.'</th>';
            echo '</tr></thead><tbody>';
            foreach ($finalRows as $row) {
                echo '<tr>';
                for ($g = 1; $g <= $realMaxGen; $g++) echo '<td style="vertical-align:top;">'.(isset($row[$g]) ? htmlspecialchars($row[$g]) : '').'</td>';
                echo '</tr>';
            }
            echo '</tbody></table></body></html>';
            exit;
        } else {
            header("Content-Type: application/msword; charset=utf-8");
            header("Content-Disposition: attachment; filename=".$filename.".doc");
            header("Cache-Control: max-age=0");
            echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">';
            echo '<head><meta charset="utf-8" /><style>@page { mso-page-orientation: landscape; size: 29.7cm 21cm; margin: 1cm; } body { font-family: "Times New Roman"; } table { border-collapse: collapse; width: 100%; border: 1px solid #000; } th, td { border: 1px solid #000; padding: 5px; vertical-align: top; }</style></head><body>';
            echo '<h2 style="text-align:center;">Laporan Pohon Keluarga</h2>';
            if ($filterRootId > 0 && isset($persons[$filterRootId])) {
                echo '<h3 style="text-align:center;">Bani: '.htmlspecialchars($persons[$filterRootId]['name']).'</h3>';
            }
            echo '<table><thead><tr>';
            for ($g = 1; $g <= $realMaxGen; $g++) echo '<th>Generasi '.$g.'</th>';
            echo '</tr></thead><tbody>';
            foreach ($finalRows as $row) {
                echo '<tr>';
                for ($g = 1; $g <= $realMaxGen; $g++) echo '<td>'.(isset($row[$g]) && $row[$g] !== '' ? htmlspecialchars($row[$g]) : '&nbsp;').'</td>';
                echo '</tr>';
            }
            echo '</tbody></table></body></html>';
            exit;
        }
    }

    // --- LOGIC PDF ---
    if ($_GET['export'] === 'pdf') {
        // Helper PDF (Internal function, copy dari sebelumnya tapi dirapikan)
        if (!function_exists('fh_render_single_card_pdf')) {
            function fh_render_single_card_pdf($p) {
                 $userPhoto = $p['photo'] ?? '';
                 $fullUserPath = __DIR__ . '/' . $userPhoto;
                 $gender = strtoupper($p['gender'] ?? '');
                 $imagePathToUse = '';
                 if (!empty($userPhoto) && file_exists($fullUserPath)) $imagePathToUse = $fullUserPath;
                 else {
                     $assetFile = ($gender === 'P') ? 'assets/p.png' : 'assets/l.png';
                     $fullAssetPath = __DIR__ . '/' . $assetFile;
                     if (file_exists($fullAssetPath)) $imagePathToUse = $fullAssetPath;
                 }
                 $avatarHtml = '';
                 if ($imagePathToUse) {
                     $ext = pathinfo($imagePathToUse, PATHINFO_EXTENSION) ?: 'png';
                     $fileContent = @file_get_contents($imagePathToUse);
                     if ($fileContent) {
                         $imgData = base64_encode($fileContent);
                         $src = 'data:image/' . $ext . ';base64,' . $imgData;
                         $avatarHtml = '<img src="'.$src.'">';
                     }
                 }
                 if (empty($avatarHtml)) {
                     $color = ($gender === 'P') ? '#ec4899' : '#3b82f6';
                     $txt   = ($gender ?: '?');
                     $avatarHtml = '<div style="background:'.$color.'; width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:bold; font-size:1.2rem;">'.$txt.'</div>';
                 }
                 echo '<div class="node-card"><div class="node-circle">' . $avatarHtml . '</div><div class="node-name">' . htmlspecialchars($p['name']) . '</div></div>';
            }
        }

        if (!function_exists('fh_pdf_recurse')) {
            function fh_pdf_recurse($personId, $persons, $spouses, $parentChildren) {
                if (!isset($persons[$personId])) return;
                echo '<li><div class="tree-content">';
                fh_render_single_card_pdf($persons[$personId]);
                if (!empty($spouses[$personId])) {
                    foreach ($spouses[$personId] as $spouseId => $_) {
                        echo '<div class="spouse-connector">❤</div>';
                        if (isset($persons[$spouseId])) fh_render_single_card_pdf($persons[$spouseId]);
                    }
                }
                echo '</div>';
                
                $groupIds = [$personId];
                if (!empty($spouses[$personId])) foreach ($spouses[$personId] as $sid => $_) $groupIds[] = $sid;
                
                $childIdsMap = [];
                foreach ($groupIds as $pid) {
                    if (!empty($parentChildren[$pid])) foreach ($parentChildren[$pid] as $cid => $_) $childIdsMap[$cid] = true;
                }
                $childIds = array_keys($childIdsMap);

                if (!empty($childIds)) {
                    usort($childIds, function($a, $b) use ($persons) {
                        $da = $persons[$a]['dob'] ?? null; $db = $persons[$b]['dob'] ?? null;
                        $ka = ($da && $da !== '0000-00-00') ? $da : null; $kb = ($db && $db !== '0000-00-00') ? $db : null;
                        if ($ka && $kb && $ka !== $kb) return strcmp($ka, $kb);
                        elseif ($ka && !$kb) return -1; elseif (!$ka && $kb) return 1;
                        return strnatcasecmp($persons[$a]['name'], $persons[$b]['name']);
                    });
                    echo '<ul>';
                    foreach ($childIds as $childId) fh_pdf_recurse($childId, $persons, $spouses, $parentChildren);
                    echo '</ul>';
                }
                echo '</li>';
            }
        }

        echo '<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><title>Pohon Keluarga PDF</title>';
        echo '<style>
        * { box-sizing: border-box; } body { margin:0; font-family: sans-serif; }
        .tree { display: table; margin: 0 auto; }
        .tree ul { padding-top: 20px; position: relative; transition: all 0.5s; display: flex; justify-content: center; }
        .tree li { float: left; text-align: center; list-style-type: none; position: relative; padding: 20px 5px 0 5px; transition: all 0.5s; }
        .tree li::before, .tree li::after { content: ""; position: absolute; top: 0; right: 50%; border-top: 1px solid #ccc; width: 50%; height: 20px; }
        .tree li::after { right: auto; left: 50%; border-left: 1px solid #ccc; }
        .tree li:only-child::after, .tree li:only-child::before { display: none; }
        .tree li:only-child { padding-top: 0; }
        .tree li:first-child::before, .tree li:last-child::after { border: 0 none; }
        .tree li:last-child::before { border-right: 1px solid #ccc; border-radius: 0 5px 0 0; }
        .tree li:first-child::after { border-radius: 5px 0 0 0; }
        .tree ul ul::before { content: ""; position: absolute; top: 0; left: 50%; border-left: 1px solid #ccc; width: 0; height: 20px; }
        .tree-content { display: flex; align-items: center; justify-content: center; gap: 5px; }
        .node-card { display: inline-block; background: #fff; border: 1px solid #ccc; padding: 5px; border-radius: 5px; min-width: 80px; }
        .node-circle { width: 40px; height: 40px; border-radius: 50%; overflow: hidden; margin: 0 auto 5px; background: #eee; }
        .node-circle img { width: 100%; height: 100%; object-fit: cover; }
        .node-name { font-size: 10px; font-weight: bold; }
        .spouse-connector { color: red; font-size: 10px; margin: 0 2px; }
        @media print { .no-print { display: none; } }
        </style></head><body onload="window.print()">';
        echo '<a href="#" onclick="window.print(); return false;" class="no-print">🖨️ Cetak PDF</a>';
        
        $title = "Diagram Keluarga Besar";
        if ($filterRootId > 0 && isset($persons[$filterRootId])) {
            $title .= " Bani " . htmlspecialchars($persons[$filterRootId]['name']);
        }
        echo '<h2 style="text-align:center;">'.$title.'</h2>';
        
        // Loop Roots yang sudah difilter
        foreach ($rootsToExport as $rootId) {
             echo '<div class="tree"><ul>';
             fh_pdf_recurse($rootId, $persons, $spouses, $parentChildren);
             echo '</ul></div><hr style="margin:40px 0; border:0; border-top:1px dashed #ccc;">';
        }
        
        echo '</body></html>';
        exit;
    }
}

function redirect($url) { header('Location: ' . $url); exit; }

function handle_photo_upload($fieldName, $oldPath = null) {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) return $oldPath;
    $uploadDir = __DIR__ . '/uploads';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    $ext = pathinfo($_FILES[$fieldName]['name'], PATHINFO_EXTENSION) ?: 'jpg';
    $newName = 'person_' . time() . '_' . mt_rand(1000, 9999) . '.' . $ext;
    $target  = $uploadDir . '/' . $newName;
    if (move_uploaded_file($_FILES[$fieldName]['tmp_name'], $target)) {
        if ($oldPath && file_exists(__DIR__ . '/' . ltrim($oldPath, '/'))) @unlink(__DIR__ . '/' . ltrim($oldPath, '/'));
        return 'uploads/' . $newName;
    }
    return $oldPath;
}

function label_gender($gender) {
    $gender = strtoupper($gender ?? '');
    return ($gender === 'L') ? 'Laki-laki' : (($gender === 'P') ? 'Perempuan' : 'Tidak diketahui');
}

function label_alive($v) {
    if ($v === null || $v === '') return 'Tidak diketahui';
    return $v ? 'Hidup' : 'Wafat';
}

function render_avatar_svg($gender) {
    $gender = strtoupper($gender ?? '');
    $imgSrc = ($gender === 'P') ? 'assets/p.png' : 'assets/l.png';
    return '<img src="' . $imgSrc . '" alt="' . $gender . '" style="width:100%; height:100%; object-fit:cover; display:block;">';
}

$action = $_GET['action'] ?? 'home';
$currentPerson = null;
$relations = [];
$parents = $children = $siblings = $spouses = [];
$otherPersons = [];
$allPersons = [];
$error = ''; $success = ''; $bio_error = ''; $bio_success = '';

// --- LOGIKA TAMBAH / EDIT / HAPUS DATA (CRUD) ---

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Pengamanan: Admin hanya boleh lihat-lihat (View Only) jika sedang mode intip
    if ($isViewingOthers) {
        die("MODE VIEW ONLY: Anda sedang melihat data user lain. Tidak diizinkan mengubah data.");
    }

    // 1. TAMBAH ORANG (QUICK)
    if (isset($_POST['create_person_quick'])) {
        $name = trim($_POST['name']??''); 
        $gender = trim($_POST['gender']??''); 
        $note = trim($_POST['note']??'');
        
        if ($name === '') { $error = "Nama kosong."; }
        else {
            // Cek dulu jumlah keluarga saat ini (Untuk deteksi Keluarga Baru vs Tambah Anggota)
            $countCheck = $mysqli->query("SELECT COUNT(*) as total FROM persons WHERE user_id = $targetUserId")->fetch_assoc()['total'];

            $stmt = $mysqli->prepare("INSERT INTO persons (user_id, name, gender, note) VALUES (?,?,?,?)");
            $stmt->bind_param("isss", $targetUserId, $name, $gender, $note);
            
            if ($stmt->execute()) {
                $success = "Anggota dibuat."; 
                
                // --- LOGIKA NOTIFIKASI TAMBAH ---
                if ($countCheck == 0) {
                    // Ini adalah anggota PERTAMA (Keluarga Baru)
                    fh_send_notification($mysqli, $targetUserId, "Keluarga Baru Terbentuk! 🌱", "Selamat! Anda telah memulai pohon keluarga baru dengan menambahkan $name.", "success");
                } else {
                    // Ini adalah penambahan anggota selanjutnya
                    fh_send_notification($mysqli, $targetUserId, "Anggota Baru Ditambahkan 👶", "$name berhasilat ditambahkan ke dalam silsilah keluarga.", "success");
                }
                // --------------------------------
                
            } else $error = $stmt->error;
            $stmt->close();
        }
    }
    
    // 2. TAMBAH ORANG (LENGKAP)
    elseif (isset($_POST['create_person_full'])) {
        $name = trim($_POST['name']??''); 
        $gender = trim($_POST['gender']??''); 
        $place_of_birth = trim($_POST['place_of_birth']??'');
        $dob = empty($_POST['date_of_birth']) ? null : $_POST['date_of_birth'];
        $alive = ($_POST['is_alive'] === '') ? 1 : (int)$_POST['is_alive'];
        $note = trim($_POST['note']??'');
        
        $from_id = intval($_POST['from_id']??0);
        $from_rel = $_POST['from_relation_type']??'';

        // Auto-detect gender jika relasi tertentu
        if ($from_rel === 'ibu') $gender = 'P'; 
        elseif ($from_rel === 'ayah') $gender = 'L';
        elseif ($from_rel === 'pasangan' && $from_id > 0) {
            // Cek gender pasangan
            $r = $mysqli->query("SELECT gender FROM persons WHERE id=$from_id AND user_id=$targetUserId")->fetch_assoc();
            if ($r) $gender = ($r['gender']=='L') ? 'P' : 'L';
        }

        if ($name === '') { 
            $error = "Nama tidak boleh kosong."; 
            $action = 'add_person'; 
        } elseif ($gender === '') { 
            $error = "Peringatan: Jenis kelamin harus dipilih."; 
            $action = 'add_person'; 
        } else {
            // INSERT dengan user_id
            $stmt = $mysqli->prepare("INSERT INTO persons (user_id, name, gender, place_of_birth, date_of_birth, is_alive, note) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param("issssss", $targetUserId, $name, $gender, $place_of_birth, $dob, $alive, $note);
            
            if ($stmt->execute()) {
                $newId = $stmt->insert_id;
                $stmt->close();
                
                // LOGIKA RELASI OTOMATIS
                if ($from_id > 0 && $from_rel !== '') {
                    $pid = $from_id; $rid = $newId; $rtype = $from_rel;
                    
                    // Insert Relasi (Pakai user_id)
                    $mysqli->query("INSERT INTO relations (user_id, person_id, related_person_id, relation_type) VALUES ($targetUserId, $pid, $rid, '$rtype')");
                    
                    // Insert Relasi Kebalikannya
                    $revType = null;
                    if ($rtype == 'ayah' || $rtype == 'ibu') $revType = 'anak';
                    elseif ($rtype == 'anak') {
                        $pg = $mysqli->query("SELECT gender FROM persons WHERE id=$pid")->fetch_assoc()['gender']??'';
                        $revType = (strtoupper($pg)=='P') ? 'ibu' : 'ayah';
                    } elseif ($rtype == 'saudara') $revType = 'saudara';
                    elseif ($rtype == 'pasangan') $revType = 'pasangan';
                    
                    if ($revType) {
                        $mysqli->query("INSERT INTO relations (user_id, person_id, related_person_id, relation_type) VALUES ($targetUserId, $rid, $pid, '$revType')");
                    }

                    // ... (Logika link siblings/parents lainnya sama, tinggal pastikan query SELECT pakai user_id jika perlu) ...
                    // Untuk keamanan & kesederhanaan, logika complex linking saya sederhanakan query-nya agar aman:
                    
                    // Contoh: Link Saudara -> Same Parents
                    if ($rtype === 'saudara' && !empty($_POST['same_parents'])) {
                         $resP = $mysqli->query("SELECT related_person_id, relation_type FROM relations WHERE person_id=$pid AND relation_type IN ('ayah','ibu') AND user_id=$targetUserId");
                         while($pd = $resP->fetch_assoc()) {
                             $parId = $pd['related_person_id']; $role = $pd['relation_type'];
                             $mysqli->query("INSERT IGNORE INTO relations (user_id, person_id, related_person_id, relation_type) VALUES ($targetUserId, $newId, $parId, '$role')");
                             $mysqli->query("INSERT IGNORE INTO relations (user_id, person_id, related_person_id, relation_type) VALUES ($targetUserId, $parId, $newId, 'anak')");
                         }
                    }
                    // (Logika link lainnya bisa ditambahkan dengan pola yang sama: tambah user_id di INSERT dan SELECT)
                }
                redirect("?action=bio&id=$newId&mode=edit");
            } else {
                $error = "Gagal menyimpan: " . $stmt->error; 
                $action = 'add_person';
            }
        }
    }
    
    // 3. UPDATE BIODATA
    elseif ($action === 'update_bio') {
        $id = intval($_POST['id']??0);
        if ($id > 0) {
            // Pastikan hanya mengupdate data milik sendiri (AND user_id=...)
            $pOld = $mysqli->query("SELECT * FROM persons WHERE id=$id AND user_id=$targetUserId")->fetch_assoc();
            
            if ($pOld) {
                $name = trim($_POST['name']??''); 
                $gender = trim($_POST['gender']??'');
                $pob = trim($_POST['place_of_birth']??'');
                $dob = empty($_POST['date_of_birth']) ? null : $_POST['date_of_birth'];
                $alive = ($_POST['is_alive'] === '') ? 1 : (int)$_POST['is_alive'];
                $note = trim($_POST['note']??'');
                $photoPath = handle_photo_upload('photo', $pOld['photo']);
                
                $stmt = $mysqli->prepare("UPDATE persons SET name=?, gender=?, place_of_birth=?, date_of_birth=?, is_alive=?, note=?, photo=? WHERE id=? AND user_id=?");
                $stmt->bind_param("ssssissii", $name, $gender, $pob, $dob, $alive, $note, $photoPath, $id, $targetUserId);
                
                if ($stmt->execute()) $bio_success = "Update berhasil."; else $bio_error = $stmt->error;
                $stmt->close();
                
                $action = 'bio'; $_GET['id'] = $id; $_GET['mode'] = 'view';
            } else {
                $bio_error = "Data tidak ditemukan atau bukan milik Anda.";
            }
        }
    }
    
    // 4. BUAT RELASI BARU (Manual)
    elseif (isset($_POST['create_relation'])) {
        $pid = intval($_POST['person_id']); 
        $rid = intval($_POST['related_person_id']); 
        $rtype = $_POST['relation_type'];
        
        if ($pid > 0 && $rid > 0 && $rtype) {
             // Insert A -> B
             $mysqli->query("INSERT IGNORE INTO relations (user_id, person_id, related_person_id, relation_type) VALUES ($targetUserId, $pid, $rid, '$rtype')");
             
             // Insert B -> A (Kebalikannya)
             $revType = null;
             if ($rtype == 'ayah' || $rtype == 'ibu') $revType = 'anak';
             elseif ($rtype == 'anak') {
                 $pg = $mysqli->query("SELECT gender FROM persons WHERE id=$pid")->fetch_assoc()['gender']??'';
                 $revType = (strtoupper($pg)=='P') ? 'ibu' : 'ayah';
             } elseif ($rtype == 'saudara') $revType = 'saudara';
             elseif ($rtype == 'pasangan') $revType = 'pasangan';
             
             if ($revType) {
                 $mysqli->query("INSERT IGNORE INTO relations (user_id, person_id, related_person_id, relation_type) VALUES ($targetUserId, $rid, $pid, '$revType')");
             }
             redirect("?action=bio&id=$pid&mode=view");
        }
    }
}

// --- LOGIKA HAPUS DATA (DELETE) ---

// Hapus Relasi
if (isset($_GET['delete_rel']) && $action === 'bio') {
    if ($isViewingOthers) die("Akses Ditolak.");
    
    $relId = intval($_GET['delete_rel']); 
    $pid = intval($_GET['id']);
    
    // Cek kepemilikan relasi
    $r = $mysqli->query("SELECT * FROM relations WHERE id=$relId AND user_id=$targetUserId")->fetch_assoc();
    if ($r) {
        $rid = $r['related_person_id']; 
        $rtype = $r['relation_type'];
        
        // Hapus relasi ini
        $mysqli->query("DELETE FROM relations WHERE id=$relId");
        
        // Hapus relasi sebaliknya (B -> A)
        $revType = null;
        if ($rtype == 'ayah' || $rtype == 'ibu') $revType = 'anak';
        elseif ($rtype == 'anak') {
             $pg = $mysqli->query("SELECT gender FROM persons WHERE id=$r[person_id]")->fetch_assoc()['gender']??'';
             $revType = (strtoupper($pg)=='P') ? 'ibu' : 'ayah';
        } elseif ($rtype == 'saudara') $revType = 'saudara';
        elseif ($rtype == 'pasangan') $revType = 'pasangan';
        
        if ($revType) {
            $mysqli->query("DELETE FROM relations WHERE person_id=$rid AND related_person_id=$pid AND relation_type='$revType' AND user_id=$targetUserId");
        }
    }
    redirect("?action=bio&id=$pid&mode=view");
}

// Hapus Orang
if (isset($_GET['delete_person'])) {
    if ($isViewingOthers) die("Akses Ditolak.");
    
    $id = intval($_GET['delete_person']);
    
    // Cek kepemilikan
    $p = $mysqli->query("SELECT photo FROM persons WHERE id=$id AND user_id=$targetUserId")->fetch_assoc();
    
    if ($p) {
        if ($p['photo']) @unlink(__DIR__ . '/' . $p['photo']);
        
        // Hapus semua relasi terkait orang ini (milik user ini)
        $mysqli->query("DELETE FROM relations WHERE (person_id=$id OR related_person_id=$id) AND user_id=$targetUserId");
        
        // Hapus orangnya
        $mysqli->query("DELETE FROM persons WHERE id=$id AND user_id=$targetUserId");
        
        $success = "Anggota dihapus."; 
        $action = 'home';
    } else {
        $error = "Gagal menghapus: Data tidak ditemukan atau bukan milik Anda.";
    }
}

if ($action === 'home') { $allPersons = fh_get_all_persons($mysqli, $targetUserId); }
if ($action === 'add_person') { $allPersons = fh_get_all_persons($mysqli, $targetUserId); }
if ($action === 'bio') {
    $id = intval($_GET['id']??0);
    if ($id > 0) {
        $currentPerson = $mysqli->query("SELECT * FROM persons WHERE id=$id")->fetch_assoc();
        if ($currentPerson) {
            $res = $mysqli->query("SELECT r.id, r.relation_type, r.related_person_id, p.name AS related_name, p.gender AS related_gender, p.photo AS related_photo FROM relations r JOIN persons p ON p.id = r.related_person_id WHERE r.person_id=$id ORDER BY FIELD(r.relation_type,'ayah','ibu','anak','saudara','pasangan'), p.name");
            $relations = $res->fetch_all(MYSQLI_ASSOC);
            $otherPersons = fh_get_all_persons($mysqli, $targetUserId); 
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>familyHood - Pohon Keluarga</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA1MTIgNTEyIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSI1MTIiIGhlaWdodD0iNTEyIiByeD0iMTIwIiBmaWxsPSJ3aGl0ZSIvPjxwYXRoIGQ9Ik0yNTYgMTUwVjI1MCIgc3Ryb2tlPSIjNGY0NmU1IiBzdHJva2Utd2lkdGg9IjMyIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNMjU2IDI1MEwxNTAgMzQwIiBzdHJva2U9IiM0ZjQ2ZTUiIHN0cm9rZS13aWR0aD0iMzIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxwYXRoIGQ9Ik0yNTYgMjUwTDM2MiAzNDAiIHN0cm9rZT0iIzRmNDZlNSIgc3Ryb2tlLXdpZHRoPSIzMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PGNpcmNsZSBjeD0iMjU2IiBjeT0iMTQwIiByPSI2MCIgZmlsbD0iIzRmNDZlNSIvPjxjaXJjbGUgY3g9IjE1MCIgY3k9IjM2MCIgcj0iNTAiIGZpbGw9IiM0ZjQ2ZTUiIGZpbGwtb3BhY2l0eT0iMC44Ii8+PGNpcmNsZSBjeD0iMzYyIiBjeT0iMzYwIiByPSI1MCIgZmlsbD0iIzRmNDZlNSIgZmlsbC1vcGFjaXR5PSIwLjgiLz48L3N2Zz4=" type="image/svg+xml">
    <style>
    /* --- RESET & UMUM --- */
    * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #f3f4f6; color: #1f2937; }
    
    /* --- UTILS --- */
    a { text-decoration: none; }
    .btn { display: inline-flex; align-items: center; justify-content: center; padding: 8px 16px; border-radius: 8px; border: none; font-size: 0.9rem; font-weight: 600; cursor: pointer; transition: 0.2s; gap: 6px; }
    .btn-primary { background: #4f46e5; color: #fff; }
    .btn-primary:hover { background: #4338ca; }
    .btn-secondary { background: #e5e7eb; color: #374151; }
    .btn-danger { background: #fee2e2; color: #991b1b; }
    .btn-success { background: #d1fae5; color: #065f46; }
    .btn-sm { padding: 6px 12px; font-size: 0.8rem; }
    .btn-block { width: 100%; display: flex; }

    .card { background: #fff; border-radius: 12px; padding: 20px; margin-bottom: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); border: 1px solid #e5e7eb; }
    .alert { padding: 12px; border-radius: 8px; margin-bottom: 15px; }
    .alert-success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
    .alert-error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }

    /* Form Elements */
    form label { display: block; font-size: 0.9rem; margin: 10px 0 5px; font-weight: 500; color: #4b5563; }
    input, select, textarea { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem; background: #fff; }
    .flex { display: flex; gap: 10px; } .flex-1 { flex: 1; }

    /* --- TAMPILAN MOBILE (DEFAULT) --- */
    body { padding-top: 70px; padding-bottom: 80px; } /* Space untuk Header & Bottom Nav */
    .container { padding: 0 15px; max-width: 100%; }
    
    /* Mobile Header (Fixed Logo) */
    .mobile-header { 
        position: fixed; top: 0; left: 0; right: 0; height: 60px; background: #fff; 
        display: flex; justify-content: center; align-items: center; z-index: 999;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .mobile-header svg { width: 32px; height: 32px; }
    
    /* Mobile Bottom Nav */
    .bottom-nav {
        position: fixed; bottom: 0; left: 0; right: 0; height: 65px; background: #fff; border-top: 1px solid #e5e7eb;
        display: flex; justify-content: space-around; align-items: center; z-index: 999;
    }
    .nav-item { display: flex; flex-direction: column; align-items: center; color: #9ca3af; font-size: 0.7rem; text-decoration: none; }
    .nav-item.active { color: #4f46e5; }
    .nav-item svg { width: 24px; height: 24px; stroke: currentColor; fill: none; stroke-width: 2; margin-bottom: 2px; }
    
    /* Tombol Tambah Tengah (Mobile) */
    .nav-item.add-btn { position: relative; top: -20px; }
    .nav-item.add-btn div { 
        width: 48px; height: 48px; background: #4f46e5; border-radius: 50%; 
        display: flex; align-items: center; justify-content: center; color: #fff; 
        box-shadow: 0 4px 10px rgba(79, 70, 229, 0.3); 
    }
    .nav-item.add-btn svg { stroke: #fff; }

    /* Sembunyikan elemen Desktop di Mobile */
    .desktop-header, .desktop-nav { display: none; }

    /* --- TAMPILAN DESKTOP (LAYAR LEBAR) --- */
    @media (min-width: 768px) {
        body { padding-top: 0; padding-bottom: 40px; } /* Reset padding */
        .container { max-width: 1000px; margin: 20px auto; }
        
        /* Sembunyikan elemen Mobile */
        .mobile-header, .bottom-nav { display: none; }
        
        /* Tampilkan elemen Desktop */
        .desktop-header { 
            display: block; background: linear-gradient(135deg, #4f46e5, #6366f1); color: #fff; 
            padding: 15px 0; margin-bottom: 0; 
        }
        .header-inner { max-width: 1000px; margin: 0 auto; padding: 0 15px; display: flex; justify-content: space-between; align-items: center; }
        
        .desktop-nav { 
            display: block; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-bottom: 20px; 
        }
        .nav-inner { max-width: 1000px; margin: 0 auto; display: flex; padding: 0 10px; }
        .d-link { 
            padding: 15px 20px; text-decoration: none; color: #4b5563; font-weight: 600; border-bottom: 3px solid transparent; font-size: 0.9rem; 
        }
        .d-link:hover { background: #f9fafb; color: #4f46e5; }
        .d-link.active { border-bottom-color: #4f46e5; color: #4f46e5; }
        .btn-block { width: auto; display: inline-flex; }
    }

    /* --- CSS TREE/POHON (SHARED) --- */
    .tree-container { overflow-x: auto; text-align: center; padding: 20px 0; }
    .tree ul { padding-top: 20px; position: relative; display: flex; justify-content: center; }
    .tree li { float: left; text-align: center; list-style-type: none; position: relative; padding: 20px 5px 0 5px; }
    .tree li::before, .tree li::after { content: ''; position: absolute; top: 0; right: 50%; border-top: 2px solid #cbd5e1; width: 50%; height: 20px; }
    .tree li::after { right: auto; left: 50%; border-left: 2px solid #cbd5e1; }
    .tree li:only-child::after, .tree li:only-child::before { display: none; }
    .tree li:only-child { padding-top: 0; }
    .tree li:first-child::before, .tree li:last-child::after { border: 0 none; }
    .tree li:last-child::before { border-right: 2px solid #cbd5e1; border-radius: 0 5px 0 0; }
    .tree li:first-child::after { border-radius: 5px 0 0 0; }
    .tree ul ul::before { content: ''; position: absolute; top: 0; left: 50%; border-left: 2px solid #cbd5e1; width: 0; height: 20px; }
    .tree-node-web { text-decoration: none; display: inline-block; }
    .node-card-content { background: #fff; border: 1px solid #e5e7eb; border-radius: 10px; padding: 5px; width: 80px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); position: relative; z-index: 2; }
    .node-card-content.highlight { border-color: #4f46e5; background: #eef2ff; }
    .web-photo { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
    .web-name { font-size: 0.7rem; font-weight: 700; display: block; line-height: 1.2; margin-top: 4px; color: #1f2937; }
    .spouse-connector-web { width: 15px; height: 2px; background: #ef4444; display: inline-block; vertical-align: middle; }
    
    /* Other Styles */
    .person-list { list-style: none; padding: 0; margin: 0; }
    .person-item { display: flex; align-items: center; padding: 10px 0; border-bottom: 1px solid #f3f4f6; }
    .person-avatar { width: 40px; height: 40px; border-radius: 50%; background: #eee; margin-right: 10px; overflow: hidden; flex-shrink: 0; }
    .person-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .person-info { flex: 1; }
    .person-name { font-weight: 600; font-size: 0.95rem; }
    .pill-menu { display:flex; gap:8px; overflow-x:auto; padding-bottom:10px; }
    .pill-item { white-space:nowrap; padding:6px 12px; border-radius:99px; background:#fff; border:1px solid #e5e7eb; color:#374151; text-decoration:none; font-size:0.85rem; }
    .pill-item.active { background:#4f46e5; color:#fff; }
    
    /* Menu List di Halaman Akun */
    .menu-list a { display: flex; align-items: center; padding: 15px; border-bottom: 1px solid #f3f4f6; color: #374151; font-weight: 500; }
    .menu-icon { margin-right: 10px; font-size: 1.2rem; }
    
    /* --- LIST ANGGOTA (PERBAIKAN LAYOUT) --- */
    .person-list { list-style: none; padding: 0; margin: 0; }
    
    .person-item { 
        display: flex; 
        align-items: center; 
        justify-content: space-between; /* Pisahkan kiri dan kanan mentok */
        padding: 15px 0; 
        border-bottom: 1px solid #f3f4f6; 
    }
    .person-item:last-child { border: none; }

    /* Bagian KIRI (Avatar + Nama) mengambil sisa ruang */
    .person-left { 
        display: flex; 
        align-items: center; 
        gap: 12px; 
        flex: 1; /* KUNCI: Ini yang mendorong tombol ke kanan */
        min-width: 0; /* Mencegah layout pecah jika nama terlalu panjang */
        padding-right: 10px; /* Jarak aman agar teks tidak menabrak tombol */
    }

    .person-avatar { 
        width: 48px; height: 48px; 
        border-radius: 50%; 
        background: #e5e7eb; 
        overflow: hidden; 
        flex-shrink: 0; 
    }
    .person-avatar img { width: 100%; height: 100%; object-fit: cover; }

    .person-info { 
        display: flex; 
        flex-direction: column; 
        justify-content: center;
        overflow: hidden; /* Potong teks jika kepanjangan */
    }

    .person-name { 
        font-size: 1rem; 
        font-weight: 600; 
        color: #111827; 
        white-space: nowrap; /* Nama satu baris */
        overflow: hidden; 
        text-overflow: ellipsis; /* Tambah ... jika nama kepanjangan */
    }
    .person-note { font-size: 0.8rem; color: #6b7280; }

    /* Bagian KANAN (Tombol) diam di tempat */
    .person-actions { 
        display: flex; 
        gap: 6px; 
        flex-shrink: 0; /* Agar tombol tidak tergencet/gepeng */
    }
    
    /* --- PERBAIKAN TAMPILAN TOOLBAR EXPORT --- */
    .export-toolbar {
        display: flex;
        flex-wrap: wrap;            /* Agar turun ke bawah jika layar sempit */
        justify-content: space-between; 
        align-items: center;
        gap: 15px;                  /* Jarak antara Judul dan Tombol */
        margin-bottom: 20px;        /* Jarak ke bawah (ke filter) */
        padding-bottom: 15px;       /* Ruang dalam bawah */
        border-bottom: 2px dashed #f3f4f6; /* Garis pemisah tipis */
    }

    .export-label {
        font-size: 1.1rem;
        font-weight: 700;
        color: #374151;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .export-actions {
        display: flex;
        gap: 10px; /* Memberi jarak antar tombol Excel, Word, PDF */
    }

    /* Mempercantik Pill Menu (Filter) */
    .pill-menu {
        display: flex;
        gap: 10px; /* Jarak antar pilihan filter lebih renggang */
        overflow-x: auto;
        padding-bottom: 10px;
        margin-top: 10px;
    }
    
    .pill-item {
        white-space: nowrap;
        padding: 8px 16px; /* Tombol filter lebih besar sedikit */
        border-radius: 99px;
        background: #fff;
        border: 1px solid #d1d5db;
        color: #4b5563;
        text-decoration: none;
        font-size: 0.85rem;
        font-weight: 500;
        transition: all 0.2s;
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    }
    
    .pill-item:hover {
        border-color: #4f46e5;
        color: #4f46e5;
    }

    .pill-item.active {
        background: #4f46e5;
        color: #fff;
        border-color: #4f46e5;
        box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.2);
    }
    
</style>
</head>
<body>

<header class="mobile-header">
    <svg viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="512" height="512" rx="100" fill="#4f46e5"/>
        <path d="M256 150V250" stroke="white" stroke-width="32" stroke-linecap="round"/>
        <path d="M256 250L150 340" stroke="white" stroke-width="32" stroke-linecap="round"/>
        <path d="M256 250L362 340" stroke="white" stroke-width="32" stroke-linecap="round"/>
        <circle cx="256" cy="140" r="60" fill="white"/>
    </svg>
</header>

<div class="desktop-header">
    <div class="header-inner">
        <div style="display:flex; align-items:center; gap:10px;">
            <svg width="30" height="30" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="512" height="512" rx="100" fill="white"/>
                <path d="M256 150V250" stroke="#4f46e5" stroke-width="32" stroke-linecap="round"/>
                <path d="M256 250L150 340" stroke="#4f46e5" stroke-width="32" stroke-linecap="round"/>
                <path d="M256 250L362 340" stroke="#4f46e5" stroke-width="32" stroke-linecap="round"/>
                <circle cx="256" cy="140" r="60" fill="#4f46e5"/>
            </svg>
            <h1 style="font-size:1.2rem; margin:0;">familyHood</h1>
        </div>
        <div style="font-size:0.9rem;">
            Halo, <strong><?= htmlspecialchars($_SESSION['user_name']) ?></strong>
        </div>
    </div>
</div>

<div class="desktop-nav">
    <div class="nav-inner">
        <a href="?action=home" class="d-link <?= ($action === 'home') ? 'active' : '' ?>">📋 Daftar Anggota</a>
        <a href="?action=add_person" class="d-link <?= ($action === 'add_person') ? 'active' : '' ?>">➕ Tambah Baru</a>
        <a href="?action=tree" class="d-link <?= ($action === 'tree') ? 'active' : '' ?>">🌳 Pohon Keluarga</a>
        
        <?php if ($isAdmin): ?>
            <a href="?action=admin_users" class="d-link <?= ($action === 'admin_users') ? 'active' : '' ?>">👑 Admin</a>
        <?php endif; ?>
        
        <a href="?action=settings" class="d-link <?= ($action === 'settings' || $action === 'support') ? 'active' : '' ?>" style="margin-left:auto;">⚙️ Akun & Bantuan</a>
        <a href="?action=notifications" class="d-link <?= ($action === 'notifications') ? 'active' : '' ?>">🔔 Info</a>
        <a href="?action=logout" class="d-link" onclick="return confirm('Keluar?')" style="color:#dc2626;">🚪 Logout</a>
    </div>
</div>



<div class="container">
    <?php if ($error): ?> <div class="alert alert-error"><?= htmlspecialchars($error) ?></div> <?php endif; ?>
    <?php if ($success): ?> <div class="alert alert-success"><?= htmlspecialchars($success) ?></div> <?php endif; ?>

    <?php if ($action === 'home'): ?>
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                <h2>Daftar Anggota Keluarga</h2>
                <?php if ($isAdmin): ?>
                <a href="?action=add_person" class="btn btn-primary btn-sm">+ Baru</a>
                <?php endif; ?>
            </div>
            <?php if (empty($allPersons)): ?>
                <div style="text-align:center; padding:20px; color:#6b7280;">
                    Belum ada data keluarga.<br>
                    <a href="?action=add_person" style="color:#4f46e5;">Tambah anggota pertama</a>
                </div>
            <?php else: ?>
                <ul class="person-list">
                    <?php foreach ($allPersons as $p): ?>
                        <li class="person-item">
                            <div class="person-left">
                                <div class="person-avatar">
                                    <?php if (!empty($p['photo'])): ?>
                                        <img src="<?= htmlspecialchars($p['photo']) ?>" alt="Foto">
                                    <?php else: ?>
                                        <?= render_avatar_svg($p['gender'] ?? '') ?>
                                    <?php endif; ?>
                                </div>
                                <div class="person-info">
                                    <span class="person-name"><?= htmlspecialchars($p['name']) ?></span>
                                    <?php if (!empty($p['note'])): ?>
                                        <span class="person-note"><?= htmlspecialchars(substr($p['note'], 0, 50)) ?>...</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="person-actions">
                                <a href="?action=bio&id=<?= $p['id'] ?>&mode=view" class="btn btn-secondary btn-sm">Lihat</a>
                                <?php if (!$isViewingOthers): // Muncul jika bukan mode intip ?>
                                <a href="?action=bio&id=<?= $p['id'] ?>&mode=edit" class="btn btn-secondary btn-sm">Edit</a>
                                <a href="?delete_person=<?= $p['id'] ?>" onclick="return confirm('Hapus anggota ini beserta semua relasinya?')" class="btn btn-danger btn-sm">Hapus</a>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

    <?php elseif ($action === 'add_person'): ?>
        <div class="card">
            <h2>Tambah Anggota Keluarga</h2>
            <?php
                $req_id  = intval($_GET['from_id'] ?? 0); $req_rel = $_GET['relation_type'] ?? ''; $pre_gender = '';
                if ($req_rel === 'ibu') $pre_gender = 'P'; elseif ($req_rel === 'ayah') $pre_gender = 'L';
                elseif ($req_rel === 'pasangan' && $req_id > 0) { $r = $mysqli->query("SELECT gender FROM persons WHERE id=$req_id")->fetch_assoc(); if ($r) $pre_gender = ($r['gender'] === 'L') ? 'P' : 'L'; }
            ?>
            <form method="post" action="?action=add_person">
                <input type="hidden" name="create_person_full" value="1">
                <input type="hidden" name="from_id" value="<?= $req_id ?>">
                <input type="hidden" name="from_relation_type" value="<?= htmlspecialchars($req_rel) ?>">
                <label>Nama Lengkap</label>
                <input type="text" name="name" required placeholder="Contoh: Budi Santoso">
                <label>Jenis Kelamin</label>
                <select name="gender" required>
                    <option value="">- Pilih -</option>
                    <option value="L" <?= ($pre_gender==='L')?'selected':'' ?>>Laki-laki</option>
                    <option value="P" <?= ($pre_gender==='P')?'selected':'' ?>>Perempuan</option>
                </select>
                <div class="flex">
                    <div class="flex-1"><label>Tempat Lahir</label><input type="text" name="place_of_birth"></div>
                    <div class="flex-1"><label>Tanggal Lahir</label><input type="date" name="date_of_birth"></div>
                </div>
                <label>Status Hidup</label>
                <select name="is_alive"><option value="1">Hidup</option><option value="0">Wafat</option></select>
                <label>Catatan</label>
                <textarea name="note" placeholder="Tambahkan catatan khusus..."></textarea>
                
                <?php if ($req_rel === 'saudara'): ?>
                    <div class="alert alert-success" style="margin-top:10px;">
                        <label style="margin:0; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:5px;">
                            <input type="checkbox" name="same_parents" value="1" checked style="width:auto;"> Satu Orang Tua?
                        </label>
                        <label style="margin:0; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:5px; margin-top:5px;">
                            <input type="checkbox" name="link_siblings" value="1" checked style="width:auto;"> Hubungkan ke saudara lain?
                        </label>
                    </div>
                <?php endif; ?>
                <?php if ($req_rel === 'anak'): ?>
                    <div class="alert alert-success" style="margin-top:10px;">
                        <label style="margin:0; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:5px;">
                            <input type="checkbox" name="link_spouse" value="1" checked style="width:auto;"> Jadikan pasangan sbg ortu juga?
                        </label>
                        <label style="margin:0; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:5px; margin-top:5px;">
                            <input type="checkbox" name="link_existing_children" value="1" checked style="width:auto;"> Hubungkan dengan kakak/adik?
                        </label>
                    </div>
                <?php endif; ?>

                <div style="margin-top:20px;">
                    <button type="submit" class="btn btn-primary">Simpan Data</button>
                    <a href="?action=home" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>

    <?php elseif ($action === 'bio' && $currentPerson): ?>
        <?php $mode = $_GET['mode'] ?? 'view'; $isEdit = ($mode === 'edit'); ?>
        <?php if ($bio_error): ?> <div class="alert alert-error"><?= $bio_error ?></div> <?php endif; ?>
        <?php if ($bio_success): ?> <div class="alert alert-success"><?= $bio_success ?></div> <?php endif; ?>

        <div class="bio-grid">
            <div class="card">
                <?php if ($isEdit): ?>
                    <h2 class="section-title">Edit Biografi</h2>
                    <form method="post" action="?action=update_bio" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $currentPerson['id'] ?>">
                        <div style="text-align:center; margin-bottom:10px;">
                            <img src="<?= !empty($currentPerson['photo']) ? htmlspecialchars($currentPerson['photo']) : 'assets/l.png' ?>" style="width:100px; height:100px; object-fit:cover; border-radius:10px;">
                            <input type="file" name="photo" style="margin-top:5px;">
                        </div>
                        <label>Nama</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($currentPerson['name']) ?>" required>
                        <div class="flex">
                            <div class="flex-1"><label>Tempat</label><input type="text" name="place_of_birth" value="<?= htmlspecialchars($currentPerson['place_of_birth']??'') ?>"></div>
                            <div class="flex-1"><label>Tanggal</label><input type="date" name="date_of_birth" value="<?= htmlspecialchars($currentPerson['date_of_birth']??'') ?>"></div>
                        </div>
                        <div class="flex">
                            <div class="flex-1">
                                <label>Gender</label>
                                <select name="gender">
                                    <option value="L" <?= $currentPerson['gender']=='L'?'selected':'' ?>>Laki-laki</option>
                                    <option value="P" <?= $currentPerson['gender']=='P'?'selected':'' ?>>Perempuan</option>
                                </select>
                            </div>
                            <div class="flex-1">
                                <label>Status</label>
                                <select name="is_alive">
                                    <option value="1" <?= $currentPerson['is_alive']==1?'selected':'' ?>>Hidup</option>
                                    <option value="0" <?= $currentPerson['is_alive']==0?'selected':'' ?>>Wafat</option>
                                </select>
                            </div>
                        </div>
                        <label>Catatan</label><textarea name="note"><?= htmlspecialchars($currentPerson['note']??'') ?></textarea>
                        <div style="margin-top:15px;">
                            <button type="submit" class="btn btn-primary btn-block">Simpan</button>
                            <a href="?action=bio&id=<?= $currentPerson['id'] ?>&mode=view" class="btn btn-secondary btn-block" style="margin-top:5px;">Batal</a>
                        </div>
                    </form>
                <?php else: ?>
                    <div style="text-align:center; margin-bottom:15px;">
                         <?php $photo = ($currentPerson['gender']=='P') ? 'assets/p.png' : 'assets/l.png'; if ($currentPerson['photo']) $photo = $currentPerson['photo']; ?>
                         <img src="<?= $photo ?>" style="width:120px; height:120px; border-radius:50%; object-fit:cover; border:4px solid #fff; box-shadow:0 2px 10px rgba(0,0,0,0.1); background:#e5e7eb;">
                         <h2 style="margin:10px 0 5px;"><?= htmlspecialchars($currentPerson['name']) ?></h2>
                         <span style="font-size:0.85rem; background:<?= $currentPerson['is_alive']?'#dcfce7':'#fee2e2' ?>; color:<?= $currentPerson['is_alive']?'#166534':'#991b1b' ?>; padding:2px 8px; border-radius:99px;">
                             <?= label_alive($currentPerson['is_alive']) ?>
                         </span>
                    </div>
                    <div style="background:#f9fafb; padding:15px; border-radius:10px; font-size:0.9rem;">
                        <p><strong>Lahir:</strong> <?= htmlspecialchars($currentPerson['place_of_birth']??'-') ?>, <?= $currentPerson['date_of_birth'] ? date('d M Y', strtotime($currentPerson['date_of_birth'])) : '-' ?></p>
                        <p><strong>Gender:</strong> <?= label_gender($currentPerson['gender']) ?></p>
                        <?php if($currentPerson['note']): ?>
                            <div style="margin-top:10px; border-top:1px dashed #d1d5db; padding-top:10px;"><strong>Catatan:</strong><br><?= nl2br(htmlspecialchars($currentPerson['note'])) ?></div>
                        <?php endif; ?>
                    </div>
                        <?php if (!$isViewingOthers): ?>
                        <a href="?action=bio&id=<?= $currentPerson['id'] ?>&mode=edit" class="btn btn-primary btn-block" style="margin-top:15px;">✏️ Edit Profil</a>
                        <?php endif; ?>
                <?php endif; ?>
            </div>

            <div class="card">
                <h2 class="section-title">Relasi Keluarga</h2>
                <?php if (empty($relations)): ?>
                    <p>Belum ada relasi.</p>
                <?php else: ?>
                    <table>
                        <thead><tr><th>Nama</th><th>Hubungan</th><th>Aksi</th></tr></thead>
                        <tbody>
                        <?php foreach ($relations as $r): ?>
                            <tr>
                                <td><?= htmlspecialchars($r['related_name']) ?></td>
                                <td><?= ucfirst($r['relation_type']) ?></td>
                                <td>
                                    <a href="?action=bio&id=<?= $r['related_person_id'] ?>&mode=view" class="btn btn-secondary btn-sm">Lihat</a>
                                    <?php if (!$isViewingOthers): ?>
                                    <a href="?action=bio&id=<?= $currentPerson['id'] ?>&delete_rel=<?= $r['id'] ?>" onclick="return confirm('Hapus relasi ini?')" class="btn btn-danger btn-sm">X</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                    <?php if (!$isViewingOthers): ?>
                    <h3 class="section-title" style="margin-top:20px;">Hubungkan / Buat Baru</h3>
                    <?php endif; ?>
                <div style="display:flex; gap:5px; flex-wrap:wrap;"> <a href="?action=add_person&from_id=<?= $currentPerson['id'] ?>&relation_type=ayah" class="btn btn-sm btn-secondary">+ Ayah</a>
                    <a href="?action=add_person&from_id=<?= $currentPerson['id'] ?>&relation_type=ibu" class="btn btn-sm btn-secondary">+ Ibu</a>
                    
                    <a href="?action=add_person&from_id=<?= $currentPerson['id'] ?>&relation_type=pasangan" class="btn btn-sm btn-success">+ Pasangan</a>
                    <a href="?action=add_person&from_id=<?= $currentPerson['id'] ?>&relation_type=anak" class="btn btn-sm btn-success">+ Anak</a>
                    <a href="?action=add_person&from_id=<?= $currentPerson['id'] ?>&relation_type=saudara" class="btn btn-sm btn-secondary">+ Saudara</a>
                </div>
                <form method="post" style="margin-top:15px; border-top:1px solid #eee; padding-top:10px;">
                    <input type="hidden" name="create_relation" value="1">
                    <input type="hidden" name="person_id" value="<?= $currentPerson['id'] ?>">
                    <label style="margin-top:0;">Hubungkan dengan yg sudah ada:</label>
                    <div class="flex">
                        <div class="flex-1">
                            <select name="related_person_id" required>
                                <option value="">- Pilih Orang -</option>
                                <?php foreach ($otherPersons as $op): if($op['id'] == $currentPerson['id']) continue; ?>
                                    <option value="<?= $op['id'] ?>"><?= htmlspecialchars($op['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="flex-1">
                            <select name="relation_type" required>
                                <option value="">- Sebagai -</option>
                                <option value="ayah">Ayah</option><option value="ibu">Ibu</option><option value="anak">Anak</option><option value="saudara">Saudara</option><option value="pasangan">Pasangan</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm" style="margin-top:5px;">Simpan</button>
                </form>
            </div>
        </div>

<?php elseif ($action === 'tree'): ?>
    <div class="card">
        <div class="export-toolbar">
            <div class="export-label">
                <span style="font-size: 1.2rem;">🌳</span> 
                <span style="font-weight:600; color:#374151;">Pohon Keluarga</span>
            </div>
            <?php 
                // Tangkap filter saat ini agar export ikut terfilter
                $fr = isset($_GET['filter_root']) ? '&filter_root='.intval($_GET['filter_root']) : ''; 
            ?>
            <div class="export-actions">
                <a href="?export=excel<?= $fr ?>" class="btn btn-success btn-sm">📊 Excel</a>
                <a href="?export=word<?= $fr ?>" class="btn btn-primary btn-sm">📝 Word</a>
                <a href="?export=pdf<?= $fr ?>" class="btn btn-danger btn-sm" target="_blank">📄 PDF</a>
            </div>
        </div>

        <?php
        // 1. AMBIL DATA GENERASI
        list($personsByGen, $maxGen, $maxHeight, $generationData, $allPersonsData, $parentChildren, $spouses) 
            = fh_compute_generations($mysqli, $targetUserId);

        // 2. CARI LELUHUR (ROOTS) SECARA MANUAL
        // Kita cari orang yang Generasinya = 1.
        $rootCandidates = [];
        foreach ($allPersonsData as $pid => $info) {
            if (($generationData[$pid] ?? 999) == 1) {
                $rootCandidates[] = $pid;
            }
        }
        
        // Urutkan nama agar menu rapi
        usort($rootCandidates, function($a, $b) use ($allPersonsData) { 
            return strnatcasecmp($allPersonsData[$a]['name'], $allPersonsData[$b]['name']); 
        });

        // 3. BUAT MENU FILTER (Deduplikasi Pasangan)
        $menuList = [];
        $processedRoots = []; // Agar suami & istri tidak muncul jadi 2 tombol berbeda

        foreach ($rootCandidates as $pid) {
            if (isset($processedRoots[$pid])) continue;

            $pName = $allPersonsData[$pid]['name'];
            $spouseId = null;

            // Cek apakah punya pasangan di Generasi 1 juga?
            if (!empty($spouses[$pid])) {
                foreach ($spouses[$pid] as $sid => $_) {
                    if (isset($generationData[$sid]) && $generationData[$sid] == 1) {
                        $spouseId = $sid;
                        $processedRoots[$sid] = true; // Tandai pasangan agar tidak dibuat tombol lagi
                        
                        // Jika Laki-laki adalah pasangan, pakai nama dia sebagai label utama
                        if (($allPersonsData[$sid]['gender']??'') === 'L') {
                            $pName = $allPersonsData[$sid]['name']; 
                        }
                    }
                }
            }
            $processedRoots[$pid] = true;

            // Hitung total keturunan (Estimasi kasar anggota di bawah dia)
            $visited = [];
            $count = fh_count_descendants([$pid], $spouses, $parentChildren, $visited);

            // Kita pakai ID orang tersebut sebagai kunci filter
            $mainIdToRender = (($allPersonsData[$pid]['gender']??'') === 'L') ? $pid : ($spouseId ?? $pid);

            $menuList[] = [
                'id'    => $mainIdToRender, 
                'label' => $pName,
                'count' => $count
            ];
        }

        // 4. LOGIKA RENDER
        // Jika ada ?filter_root=ID, maka hanya render ID tersebut.
        $targetRootId = isset($_GET['filter_root']) ? intval($_GET['filter_root']) : null;
        
        $rootsToRender = [];
        if ($targetRootId) {
            $rootsToRender[] = $targetRootId;
        } else {
            // Default: Tampilkan semua leluhur
            foreach ($menuList as $m) $rootsToRender[] = $m['id'];
        }
        ?>

        <div style="margin-bottom: 20px;">
            <div style="font-size:0.85rem; color:#6b7280; margin-bottom:5px; font-weight:600;">
                Filter Bani / Leluhur:
            </div>
            <div class="pill-menu">
                <a href="?action=tree" 
                   class="pill-item <?= ($targetRootId === null) ? 'active' : '' ?>">
                    🌍 Tampilkan Semua
                </a>
                
                <?php foreach ($menuList as $menu): ?>
                    <a href="?action=tree&filter_root=<?= $menu['id'] ?>" 
                       class="pill-item <?= ($targetRootId === $menu['id']) ? 'active' : '' ?>">
                       👤 <?= htmlspecialchars($menu['label']) ?> 
                       <span style="font-size:0.75em; opacity:0.8;">(<?= $menu['count'] ?>)</span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="tree-container">
            <div class="tree">
                <ul>
                <?php
                    if (empty($rootsToRender)) {
                        echo "<p style='padding:20px;'>Data tidak ditemukan.</p>";
                    } else {
                        $globalProcessed = []; 

                        foreach ($rootsToRender as $rootId) {
                            // Agar tidak double render jika tampilkan semua
                            if (isset($globalProcessed[$rootId])) continue;

                            fh_render_tree_web($rootId, $allPersonsData, $spouses, $parentChildren, 0);
                            
                            $globalProcessed[$rootId] = true;
                            // Tandai pasangan juga agar tidak digambar ulang
                            if (!empty($spouses[$rootId])) {
                                foreach($spouses[$rootId] as $sid => $_) $globalProcessed[$sid] = true;
                            }
                        }
                    }
                ?>
                </ul>
            </div>
        </div>
        
        <p style="text-align:center; color:#9ca3af; font-size:0.8rem; margin-top:10px;">
            <small>Tips: Klik tombol di atas untuk fokus pada satu garis keturunan.</small>
        </p>

    </div>
    
    
<?php elseif ($action === 'notifications'): ?>
    <div class="card" style="border:none; background:transparent; box-shadow:none; padding:0;">
        <h2 style="margin-bottom:15px;">🔔 Notifikasi Anda</h2>
        
        <?php
        // Ambil notifikasi: Milik User Ini ATAU Broadcast (0)
        $sqlNotif = "SELECT * FROM notifications 
                     WHERE user_id = $myUserId OR user_id = 0 
                     ORDER BY created_at DESC LIMIT 30";
        $resNotif = $mysqli->query($sqlNotif);
        ?>

        <?php if ($resNotif && $resNotif->num_rows > 0): ?>
            <div style="display:flex; flex-direction:column; gap:12px;">
                <?php while ($row = $resNotif->fetch_assoc()): 
                    // Styling icon berdasarkan tipe
                    $icon = 'ℹ️'; $color = '#3b82f6'; $bg = '#eff6ff';
                    if($row['type'] == 'success') { $icon = '🌱'; $color = '#10b981'; $bg = '#ecfdf5'; }
                    if($row['type'] == 'birthday') { $icon = '🎂'; $color = '#f43f5e'; $bg = '#fff1f2'; }
                    if($row['type'] == 'warning') { $icon = '⚠️'; $color = '#f59e0b'; $bg = '#fffbeb'; }
                ?>
                    <div style="background:#fff; padding:15px; border-radius:12px; border-left: 5px solid <?= $color ?>; box-shadow:0 2px 4px rgba(0,0,0,0.05); display:flex; gap:12px;">
                        <div style="font-size:1.5rem; background:<?= $bg ?>; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                            <?= $icon ?>
                        </div>
                        <div>
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                                <strong style="color:#1f2937; font-size:0.95rem;"><?= htmlspecialchars($row['title']) ?></strong>
                            </div>
                            <p style="color:#4b5563; margin:0; font-size:0.9rem; line-height:1.4;">
                                <?= nl2br(htmlspecialchars($row['message'])) ?>
                            </p>
                            <small style="color:#9ca3af; font-size:0.75rem; margin-top:8px; display:block;">
                                <?= date('d M Y, H:i', strtotime($row['created_at'])) ?>
                            </small>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="card" style="text-align:center; padding:50px 20px;">
                <div style="font-size:3rem; margin-bottom:10px; opacity:0.3;">📭</div>
                <h3 style="color:#374151; margin:0;">Belum ada notifikasi</h3>
                <p style="color:#6b7280; font-size:0.9rem;">Info keluarga dan pengumuman akan muncul di sini.</p>
            </div>
        <?php endif; ?>
        
        <?php if ($resNotif && $resNotif->num_rows > 0): ?>
            <form method="post" style="text-align:center; margin-top:20px;">
                <input type="hidden" name="clear_notif" value="1">
                <button type="submit" class="btn btn-secondary btn-sm" onclick="return confirm('Hapus semua notifikasi?')">Bersihkan Riwayat</button>
            </form>
            <?php
            if(isset($_POST['clear_notif'])) {
                // Hapus hanya milik user (jangan hapus broadcast ID 0 karena milik semua orang)
                $mysqli->query("DELETE FROM notifications WHERE user_id = $myUserId");
                echo "<script>window.location.href='?action=notifications';</script>";
            }
            ?>
        <?php endif; ?>
    </div>


<?php elseif ($action === 'settings'): ?>
    <div class="card" style="padding:0; overflow:hidden;">
        <div style="background: linear-gradient(135deg, #4f46e5, #6366f1); color:#fff; padding:30px 20px; text-align:center;">
            <div style="width:80px; height:80px; background:#fff; color:#4f46e5; font-size:2rem; font-weight:bold; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 10px;">
                <?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?>
            </div>
            <h2 style="margin:0; font-size:1.2rem; color:#fff;"><?= htmlspecialchars($_SESSION['user_name']) ?></h2>
            <p style="margin:5px 0 0; opacity:0.8; font-size:0.9rem; color:#e0e7ff;"><?= htmlspecialchars($_SESSION['user_email']) ?></p>
        </div>

        <div class="menu-list">
            <?php if ($isAdmin): ?>
            <a href="?action=admin_users" style="color:#4f46e5;">
                <span class="menu-icon">👑</span> Dashboard Admin
            </a>
            <?php endif; ?>

            <a href="?action=support">
                <span class="menu-icon">📩</span> Pusat Bantuan / Feedback
            </a>
            
            <div style="padding:15px; border-bottom:1px solid #f3f4f6;">
                <?php
                if (isset($_POST['toggle_privacy'])) {
                    $newVal = $_POST['allow_val'] == 1 ? 0 : 1;
                    $mysqli->query("UPDATE users SET allow_admin_view=$newVal WHERE id=$myUserId");
                    echo "<script>window.location.href='?action=settings';</script>"; // Refresh
                }
                $me = $mysqli->query("SELECT allow_admin_view FROM users WHERE id=$myUserId")->fetch_assoc();
                $isAllowed = $me['allow_admin_view'] == 1;
                ?>
                <form method="post" style="display:flex; justify-content:space-between; align-items:center; margin:0;">
                    <input type="hidden" name="toggle_privacy" value="1">
                    <input type="hidden" name="allow_val" value="<?= $isAllowed ? 1 : 0 ?>">
                    <div style="font-weight:500;">Izinkan Admin Lihat Data</div>
                    <button type="submit" style="background:<?= $isAllowed?'#10b981':'#e5e7eb' ?>; border:none; width:50px; height:26px; border-radius:99px; position:relative; cursor:pointer; transition:0.3s;">
                        <div style="width:20px; height:20px; background:#fff; border-radius:50%; position:absolute; top:3px; left:<?= $isAllowed?'27px':'3px' ?>; transition:0.3s; box-shadow:0 1px 3px rgba(0,0,0,0.2);"></div>
                    </button>
                </form>
                <div style="font-size:0.75rem; color:#6b7280; margin-top:5px;">Jika aktif, admin bisa membantu mengecek pohon keluarga Anda.</div>
            </div>

            <a href="?action=logout" onclick="return confirm('Keluar dari aplikasi?')" style="color:#ef4444;">
                <span class="menu-icon">🚪</span> Keluar Aplikasi
            </a>
        </div>
    </div>

<?php elseif ($action === 'support'): ?>
    <div class="card">
        <h2>📩 Pusat Bantuan & Feedback</h2>
        
        <?php
        // Proses Kirim Tiket
        if (isset($_POST['send_ticket'])) {
            $subj = trim($_POST['subject']);
            $msg  = trim($_POST['message']);
            if ($subj && $msg) {
                $stmt = $mysqli->prepare("INSERT INTO support_tickets (user_id, subject, message) VALUES (?, ?, ?)");
                $stmt->bind_param("iss", $myUserId, $subj, $msg);
                $stmt->execute();
                echo "<div class='alert alert-success'>Pesan terkirim! Admin akan segera membalas.</div>";
            }
        }
        ?>

        <form method="post" style="margin-bottom:30px;">
            <input type="hidden" name="send_ticket" value="1">
            <label>Judul Masalah / Permintaan Fitur</label>
            <input type="text" name="subject" required placeholder="Misal: Data error atau Request fitur PDF">
            <label>Pesan Detail</label>
            <textarea name="message" required placeholder="Jelaskan masalah atau ide Anda..."></textarea>
            <button type="submit" class="btn btn-primary" style="margin-top:10px;">Kirim Pesan</button>
        </form>

        <h3 class="section-title">Riwayat Pesan Anda</h3>
        <?php
        $tickets = $mysqli->query("SELECT * FROM support_tickets WHERE user_id=$myUserId ORDER BY created_at DESC");
        if ($tickets->num_rows > 0):
            while ($t = $tickets->fetch_assoc()):
        ?>
            <div style="border:1px solid #e5e7eb; border-radius:8px; padding:15px; margin-bottom:10px; background:#fff;">
                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                    <strong><?= htmlspecialchars($t['subject']) ?></strong>
                    <span style="font-size:0.8rem; color:#9ca3af;"><?= date('d M Y H:i', strtotime($t['created_at'])) ?></span>
                </div>
                <p style="color:#4b5563; margin-bottom:10px;"><?= nl2br(htmlspecialchars($t['message'])) ?></p>
                
                <?php if ($t['admin_reply']): ?>
                    <div style="background:#ecfdf5; padding:10px; border-radius:6px; border-left:4px solid #10b981; font-size:0.9rem;">
                        <strong>👑 Balasan Admin:</strong><br>
                        <?= nl2br(htmlspecialchars($t['admin_reply'])) ?>
                    </div>
                <?php else: ?>
                    <div style="font-size:0.8rem; color:#d97706; background:#fffbeb; display:inline-block; padding:2px 8px; border-radius:99px;">⏳ Menunggu balasan</div>
                <?php endif; ?>
            </div>
        <?php endwhile; else: ?>
            <p style="color:#6b7280; text-align:center;">Belum ada riwayat pesan.</p>
        <?php endif; ?>
    </div>

<?php elseif ($action === 'admin_users' && $isAdmin): ?>
    <div class="card">
        <h2>👑 Dashboard Admin</h2>
        
        <h3 class="section-title">Daftar Pengguna</h3>
        <div style="overflow-x:auto;">
            <table>
                <thead><tr><th>ID</th><th>Nama</th><th>Email</th><th>Akses Data</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php
                $users = $mysqli->query("SELECT id, name, email, allow_admin_view, created_at FROM users WHERE role != 'admin' ORDER BY created_at DESC");
                while ($u = $users->fetch_assoc()):
                ?>
                    <tr>
                        <td>#<?= $u['id'] ?></td>
                        <td><?= htmlspecialchars($u['name']) ?></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td>
                            <?php if ($u['allow_admin_view']): ?>
                                <span style="color:green; font-weight:bold;">✅ Diizinkan</span>
                            <?php else: ?>
                                <span style="color:#9ca3af;">🔒 Private</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($u['allow_admin_view']): ?>
                                <a href="?action=home&view_user_id=<?= $u['id'] ?>" class="btn btn-sm btn-primary" target="_blank">👁️ Lihat Pohon</a>
                            <?php else: ?>
                                <button class="btn btn-sm btn-secondary" disabled style="opacity:0.5;">Terkunci</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <div style="margin-top:40px; padding-top:20px; border-top:2px dashed #e5e7eb;">
            <h3 class="section-title">📢 Kirim Pengumuman / Notifikasi</h3>
            
            <?php
            if (isset($_POST['send_broadcast'])) {
                $targetUser = intval($_POST['broadcast_target']);
                $bTitle = trim($_POST['broadcast_title']);
                $bMsg = trim($_POST['broadcast_message']);
                
                if ($bTitle && $bMsg) {
                    // Fungsi helper kita tadi
                    fh_send_notification($mysqli, $targetUser, $bTitle, $bMsg, 'info');
                    echo "<div class='alert alert-success'>Notifikasi berhasil dikirim!</div>";
                }
            }
            ?>
            
            <form method="post" style="background:#f9fafb; padding:15px; border-radius:10px;">
                <input type="hidden" name="send_broadcast" value="1">
                
                <label>Tujuan:</label>
                <select name="broadcast_target" required>
                    <option value="0">📢 SEMUA USER (Broadcast)</option>
                    <?php 
                    // Ambil list user lagi untuk dropdown
                    $usersList = $mysqli->query("SELECT id, name FROM users WHERE role != 'admin'");
                    while($u = $usersList->fetch_assoc()) {
                        echo "<option value='".$u['id']."'>👤 ".$u['name']."</option>";
                    }
                    ?>
                </select>
                
                <label>Judul:</label>
                <input type="text" name="broadcast_title" placeholder="Contoh: Update Sistem" required>
                
                <label>Pesan:</label>
                <textarea name="broadcast_message" placeholder="Tulis pesan..." required></textarea>
                
                <button type="submit" class="btn btn-primary" style="margin-top:10px;">Kirim Notifikasi</button>
            </form>
        </div>

        <h3 class="section-title" style="margin-top:30px;">Tiket Bantuan Masuk</h3>
        
        <?php
        // Proses Balas Tiket
        if (isset($_POST['reply_ticket'])) {
            $tid = intval($_POST['ticket_id']);
            $reply = trim($_POST['reply']);
            if ($reply) {
                $stmt = $mysqli->prepare("UPDATE support_tickets SET admin_reply=?, status='answered' WHERE id=?");
                $stmt->bind_param("si", $reply, $tid);
                $stmt->execute();
                echo "<div class='alert alert-success'>Balasan terkirim.</div>";
            }
        }
        
        $allTickets = $mysqli->query("SELECT t.*, u.name as user_name FROM support_tickets t JOIN users u ON t.user_id = u.id ORDER BY t.status ASC, t.created_at DESC");
        ?>
        
        <?php if ($allTickets->num_rows > 0): ?>
            <?php while ($at = $allTickets->fetch_assoc()): ?>
                <div style="border:1px solid <?= $at['status']=='open' ? '#fcd34d' : '#e5e7eb' ?>; border-radius:8px; padding:15px; margin-bottom:15px; background:<?= $at['status']=='open' ? '#fffbeb' : '#fff' ?>;">
                    <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                        <strong><?= htmlspecialchars($at['user_name']) ?>: <?= htmlspecialchars($at['subject']) ?></strong>
                        <span style="font-size:0.8rem;"><?= date('d M H:i', strtotime($at['created_at'])) ?></span>
                    </div>
                    <p style="margin-bottom:10px; font-size:0.9rem;"><?= nl2br(htmlspecialchars($at['message'])) ?></p>
                    
                    <?php if (empty($at['admin_reply'])): ?>
                        <form method="post" style="display:flex; gap:5px;">
                            <input type="hidden" name="ticket_id" value="<?= $at['id'] ?>">
                            <input type="text" name="reply" placeholder="Tulis balasan..." required style="flex:1;">
                            <button type="submit" name="reply_ticket" class="btn btn-sm btn-success">Kirim Balasan</button>
                        </form>
                    <?php else: ?>
                        <div style="border-top:1px dashed #ccc; padding-top:5px; font-size:0.85rem; color:#059669;">
                            <strong>Balasan Anda:</strong> <?= htmlspecialchars($at['admin_reply']) ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="color:#6b7280;">Tidak ada tiket bantuan.</p>
        <?php endif; ?>
    </div>

<?php endif; ?>

</div>

<nav class="bottom-nav">
    <a href="?action=home" class="nav-item <?= ($action === 'home') ? 'active' : '' ?>">
        <svg viewBox="0 0 24 24"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"></path></svg>
        Daftar
    </a>

    <a href="?action=tree" class="nav-item <?= ($action === 'tree') ? 'active' : '' ?>">
        <svg viewBox="0 0 24 24"><path d="M12 3v18m-7-6l7-7 7 7m-7 7v-4"></path><circle cx="12" cy="5" r="2"></circle></svg>
        Pohon
    </a>

    <a href="?action=add_person" class="nav-item add-btn">
        <div>
            <svg viewBox="0 0 24 24" style="width:30px; height:30px;"><path d="M12 5v14m-7-7h14"></path></svg>
        </div>
    </a>
    
    <a href="?action=notifications" class="nav-item <?= ($action === 'notifications') ? 'active' : '' ?>">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
        Info
    </a>

    <a href="?action=settings" class="nav-item <?= ($action === 'settings' || $action === 'support' || $action === 'admin_users') ? 'active' : '' ?>">
        <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
        Akun
    </a>
</nav>
</body>
</html>